#include <iostream>
#include <vector>
#include <thread>

using namespace std;

void generar_fibo(unsigned int n)
{
    vector <unsigned int> temp;
    if (n <= 1)
    {
        temp.push_back(n);
    }
    else {
        unsigned int n_2 = 0, n_1 = 1, fibo = 0;
        for (int i = 1; i < n; i++)
        {
            fibo = n_2 + n_1;
            n_2 = n_1;
            n_1 = fibo;
            temp.push_back(fibo);

        }

        for (auto c : temp)
        {
            cout << c << " ";
        }

    }
}

int main() {
    auto* t1 = new thread(generar_fibo,10);
    t1->join();
    delete t1;
    return 0;
}