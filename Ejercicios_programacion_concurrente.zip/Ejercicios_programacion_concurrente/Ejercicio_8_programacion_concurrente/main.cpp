#include <iostream>
#include <thread>
#include <mutex>

using namespace std;

struct nodo{
    int val;
    nodo* next;
};

class lista_enlazada{
private:
    nodo node;
    nodo* head;
    nodo* tail;
    mutex mutex;
public:
    lista_enlazada(){head = nullptr; tail = nullptr;}

    void push_back(int value){
        std::lock_guard<std::mutex> lock(mutex);
        if(head == nullptr){
            nodo* newNode = new nodo();
            newNode -> val = value;
            newNode -> next = head;
            head = newNode;
            tail = newNode;
        }
        else{
            nodo* newNode = new nodo();
            newNode -> val = value;
            newNode -> next = head;
            head = newNode;
        }
    }

    void pop_back(){
        nodo* temp = new nodo();
        temp = head;
        head = temp->next;
        delete temp;
    }

    void printList(){
        nodo* temp = new nodo();
        temp = head;
        while(temp != nullptr){
            cout << temp->val << ' ';
            temp = temp->next;
        }
    }

};


int main(){
    lista_enlazada lista1;
    thread t1(&lista_enlazada::push_back, &lista1,5);
    thread t2(&lista_enlazada::push_back, &lista1,10);
    thread t3(&lista_enlazada::push_back, &lista1,15);
    thread t4(&lista_enlazada::push_back, &lista1,20);

    t1.join();
    t2.join();
    t3.join();
    t4.join();
    lista1.printList();

    return 0;
}