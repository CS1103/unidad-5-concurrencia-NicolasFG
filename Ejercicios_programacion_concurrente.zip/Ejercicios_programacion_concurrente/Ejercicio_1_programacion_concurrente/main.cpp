#include <iostream>
#include <thread>
#include <vector>
#include <list>
using namespace std;


void suma_enteros(vector<int> c)
{
    int sum = 0;
    for(auto it = c.begin(); it != c.end();it++ )
    {
        sum = sum + *it;
    }

   cout << sum;
}

void suma_flotantes(vector<float> c)
{
    float sum = 0;
    for(auto it = c.begin(); it != c.end();it++ )
    {
        sum = sum + *it;
    }

    cout << sum;
}


int main() {

vector <int> vec1 = {1,2,3};
vector <float> vec2 = {1.2,4.2,4.9};

auto* t1 = new thread(suma_enteros,vec1);
t1->join();
cout << endl;
auto* t2 = new thread(suma_flotantes,vec2);
t2->join();

delete t1;
delete t2;
    return 0;
}