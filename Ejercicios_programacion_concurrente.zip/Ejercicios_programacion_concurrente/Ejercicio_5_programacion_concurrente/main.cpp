#include <iostream>
#include <vector>
#include <thread>


using namespace std;


void eliminar_item(const vector<int>& t, int a)
{
    vector <int> temp;
    for(auto it = t.begin(); it != t.end(); it++)
    {
        if (*it != a)
        {
            temp.push_back(*it);
        }
    }

    for(auto n : temp)
    {
        cout << n << " ";
    }

}

int main() {

    vector<int> vec1 = {1,2,3,1,2,3,4,2};

    auto* t1 = new thread(eliminar_item,vec1,2);
    t1->join();
    delete t1;

    return 0;
}