#include <iostream>
#include <vector>
#include <random>
#include <thread>

using namespace std;

void generar_numeros(int cuantos)
{
    vector <int> random;
    int n, d;
    int es_primo;

    n = 2;
    while (cuantos > 0)
    {
            /* determinar si n es primo */
            es_primo = 1;
            for (d = 2; d < n; ++d) {
                if (n % d == 0) {
                    es_primo = 0;
                    break;
                }
            }
            /* mostrar el numero
             * y actualizar el contador */
            if (es_primo)
            {
                random.push_back(n);
                cuantos--;
            }
            n++;
        }
    for(auto it:random){
        cout << it <<" ";
    }

}
int main() {

    auto* t1 = new thread(generar_numeros,10);
    t1->join();

delete t1;
return 0;
}