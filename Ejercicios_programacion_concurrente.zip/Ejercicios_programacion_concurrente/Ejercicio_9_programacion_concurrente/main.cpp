#include <iostream>
#include <list>
#include <vector>
#include <thread>
using namespace std;


void busqueda(vector<int> l1, int n)
{
    auto medio = l1.size()/2;
    vector<int> derecha;
    vector<int> izquierda;
    int valor_medio = l1[medio];
    int valor_maximo = l1[l1.size()];

    for(auto it = l1.begin(); it != (l1.begin() + medio) ; it++)
    {
        izquierda.push_back(*it);
    }

    for(auto it = (l1.begin() + medio + 1); it != l1.end();it++)
    {
        derecha.push_back(*it);
    }


    if(valor_medio == n)
    {
        cout <<"Elemento encontrado en la mitad ";
    }

    else if(n < valor_medio)
    {
        for(int & it2 : izquierda)
        {
            if(n == it2)
            {
                cout <<"Elemento encontrado";
            }
        }
    }
    else if(n > valor_medio)
    {
        for(int & it2 : derecha)
        {
            if(n == it2)
            {
                cout <<"Elemento encontrado";
            }

        }
    }
}




int main()
{
    new thread();

    vector<int> vec1 = {1,2,3,4,5,6,7,8,9};
    thread t1(busqueda,vec1,5);
    t1.join();

    return 0;
}