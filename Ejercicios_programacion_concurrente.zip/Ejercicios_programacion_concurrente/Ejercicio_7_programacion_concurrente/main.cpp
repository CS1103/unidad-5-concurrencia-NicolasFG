#include <vector>
#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

using std::vector; using std::endl; using std::cout;

//using namespace std;

std::mutex mtx;

std::condition_variable cv;
int r = 0;
bool listo(){return r!=0;}

void mergeSort(vector<int>&left, vector<int>& right, vector<int>& bars)
{
    int nL = left.size();
    int nR = right.size();
    int i = 0, j = 0, k = 0;

    while (j < nL && k < nR) {
        if (left[j] < right[k]) {
            bars[i] = left[j];
            j++;
        }
        else {
            bars[i] = right[k];
            k++;
        }
        i++;
    }
    while (j < nL) {
        bars[i] = left[j];
        j++; i++;
    }
    while (k < nR) {
        bars[i] = right[k];
        k++; i++;
    }
}

void sort(vector<int> & bar) {
    if (bar.size() <= 1) return;

    int mid = bar.size() / 2;
    vector<int> left;
    vector<int> right;

    for (size_t j = 0; j < mid;j++)
        left.push_back(bar[j]);
    for (size_t j = 0; j < (bar.size()) - mid; j++)
        right.push_back(bar[mid + j]);

    std::thread t1(sort,std::ref(left));
    std::thread t2(sort,std::ref(right));
    t1.join();
    t2.join();

    mergeSort(left, right, bar);
}

void imprimir_vector(vector<int>& v){
    std::unique_lock<std::mutex> lock(mtx);
    cv.wait(lock,listo);
    for(auto it : v){
        cout << it << ' ';
    }
}

int main() {
    vector<int> vec1 {2,4,1,25,27,35,23};

    std::thread tv([&vec1](){
        sort(vec1);
        r = 1;
        cv.notify_one();
    });

    std::thread tn(imprimir_vector,std::ref(vec1));

    tv.join();
    tn.join();

    return 0;
}